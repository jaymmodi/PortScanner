/*
 * pssetup.cpp
 *
 *  Created on: Nov 2, 2014
 *      Author: vivek
 */

#include "pssetup.h"

ps_setup::ps_setup() {
	// TODO Auto-generated constructor stub

}

ps_setup::~ps_setup() {
	// TODO Auto-generated destructor stub
}

void ps_setup::parseargs(int argc, char **argv) {
	int c;
	bool prefixflag = false;
	bool ipflag = false;
	bool fileflag = false;
	bool portflag = false;

	while (1) {
		static struct option long_options[] = { { "help", no_argument, 0, 'h' },
				{ "ports", required_argument, 0, 'p' }, { "ip",
				required_argument, 0, 'i' }, { "prefix",
				required_argument, 0, 'c' }, { "file",
				required_argument, 0, 'f' }, { "speedup",
				required_argument, 0, 't' }, { "scan",
				required_argument, 0, 's' }, { 0, 0, 0, 0 } };
		/* getopt_long stores the option index here. */
		int option_index = 0;

		c = getopt_long(argc, argv, "hp:i:c:f:t:s:", long_options,
				&option_index);

		/* Detect the end of the options. */
		if (c == -1)
			break;

		switch (c) {

		case 'h':			//help
			printHelp();
			break;

		case 'p':			//ports
			portflag = true;
			generatePorts(optarg);
			break;

		case 'i':			//ips
			ipflag = true;
			cout << optarg << endl; // add this to vector
			break;

		case 'c':			//prefix CIDR
			prefixflag = true;
			generatePrefix(optarg);
			break;

		case 'f':			//file open
			fileflag = true;
			openFile(optarg);
			break;

		case 't':			//speedup threads
			break;

		case 's':			//scans
			if (fileflag || prefixflag || ipflag) {
				//scan logic

			} else {
				cout << "Please enter a IP or File name or Prefix ." << endl;
				printHelp();
				exit(1);
			}
			break;
		default:
			cout << "Please enter a IP or File name or Prefix ." << endl;
			printHelp();
			exit(1);
		}
	}

	if (!(fileflag || prefixflag || ipflag)) {
		cout << "Please enter a IP or File name or Prefix" << endl;
		printHelp();
		exit(1);

	}

}

void ps_setup::printHelp() {
	cout << "MAN PAGE PORTSCANNER:" << endl;
	cout << "COMMAND:" << endl;
	cout << "“$./portScanner [option1, ..., optionN]”\n" << endl;
	cout << "OPTIONS\t\t\tEXAMPLE" << endl;
	cout << "1 --help. Example: “./portScanner --help”." << endl;
	cout
			<< "2 --ports <ports to scan>. Example: “./portScanner --ports 1,2,3-5”."
			<< endl;
	cout
			<< "3 --ip <IP address to scan>. Example: “./portScanner --ip 127.0.0.1”."
			<< endl;
	cout
			<< "4 --prefix <IP prefix to scan>. Example: “./portScanner --prefix 127.143.151.123/24”."
			<< endl;
	cout
			<< "5 --file <file name containing IP addresses to scan>. Example: “./portScanner --file filename.txt”."
			<< endl;
	cout
			<< "6 --speedup <parallel threads to use>. Example: “./portScanner --speedup 10”."
			<< endl;
	cout
			<< "7 --scan <one or more scans>. Example: “./portScanner --scan SYN NULL FIN XMAS”."
			<< endl;
}

void ps_setup::generatePrefix(char* optarg) {
	int CIDRNo = 0;
	int secondOctet = 0;
	int thirdOctet = 0;
	int fourthOctet = 0;
	int firstOctet = 0;
	int rangeOfIPaddress = 0;
	int startIndexOf4thOctet = 0;
	int lastIndexOf4thOctet = 0;
	int startIndexof3rdOctet = 0;
	int lastIndexof3rdOctet = 0;
	int startIndexof2ndOctet = 0;
	int lastIndexof2ndOctet = 0;
	int startIndexof1stOctet = 0;
	int lastIndexof1stOctet = 0;

	int i = 0;
	char * word;
	//only can have 2 tokens max, but may have less
	for (word = strtok(optarg, "./"), i = 0; (word && i < 5);
			word = strtok(NULL, "./"), i++) {
		//printf("%d:%s\n",i,word);
		switch (i) {
		case 0:			//firstOctet
			firstOctet = atoi(word);
			break;
		case 1:			//SecondOctet
			secondOctet = atoi(word);
			break;
		case 2:			//ThirdOctet
			thirdOctet = atoi(word);
			break;
		case 3:			//FourthOctet
			fourthOctet = atoi(word);
			break;
		case 4:			//CIDRindex
			CIDRNo = atoi(word);
			break;
		default:
			break;
		}

	}

	if (CIDRNo >= 24 && CIDRNo < 32) {
		rangeOfIPaddress = pow(2, 32 - CIDRNo);
		startIndexOf4thOctet = fourthOctet - (fourthOctet % rangeOfIPaddress);
		lastIndexOf4thOctet = startIndexOf4thOctet + rangeOfIPaddress - 1;

		startIndexof1stOctet = lastIndexof1stOctet = firstOctet;
		startIndexof2ndOctet = lastIndexof2ndOctet = secondOctet;
		startIndexof3rdOctet = lastIndexof3rdOctet = thirdOctet;

	}
	if (CIDRNo >= 16 && CIDRNo < 24) {
		rangeOfIPaddress = pow(2, 32 - CIDRNo);
		startIndexof3rdOctet = thirdOctet;
		lastIndexof3rdOctet = thirdOctet + ((rangeOfIPaddress / 256) - 1); // 256 is the maximum number of variation

		startIndexof1stOctet = lastIndexof1stOctet = firstOctet;
		startIndexof2ndOctet = lastIndexof2ndOctet = secondOctet;
		startIndexOf4thOctet = 0;
		lastIndexOf4thOctet = 255;

	}
	if (CIDRNo >= 8 && CIDRNo < 16) {
		rangeOfIPaddress = pow(2, 32 - CIDRNo);
		startIndexof2ndOctet = secondOctet;
		lastIndexof2ndOctet = secondOctet
				+ ((rangeOfIPaddress / 256 / 256) - 1);

		startIndexof1stOctet = lastIndexof1stOctet = firstOctet;
		startIndexOf4thOctet = 0;
		lastIndexOf4thOctet = 255;

		startIndexof3rdOctet = 0;
		lastIndexof3rdOctet = 255;

	}
	if (CIDRNo < 8) {
		rangeOfIPaddress = pow(2, 32 - CIDRNo);
		startIndexof1stOctet = firstOctet;
		lastIndexof1stOctet = firstOctet
				+ ((rangeOfIPaddress / 256 / 256 / 256) - 1);

		startIndexOf4thOctet = 0;
		lastIndexOf4thOctet = 255;

		startIndexof3rdOctet = 0;
		lastIndexof3rdOctet = 255;

		startIndexof2ndOctet = 0;
		lastIndexof2ndOctet = 255;

	}
	for (int l = startIndexof1stOctet; l <= lastIndexof1stOctet; l++) {
		for (int k = startIndexof2ndOctet; k <= lastIndexof2ndOctet; k++) {
			for (int j = startIndexof3rdOctet; j <= lastIndexof3rdOctet; j++) {
				for (int i = startIndexOf4thOctet; i <= lastIndexOf4thOctet;
						i++) {
					cout << l << "." << k << "." << j << "." << i << endl;
				}
			}
		}
	}
}
void ps_setup::openFile(char* optarg) {
	string ipOnLine;
	std::ifstream ifs;
	ifs.open(optarg, std::ifstream::in);

	while (ifs.good()) {
		std::getline(ifs, ipOnLine);
		struct sockaddr_in sa;
		if (inet_pton(AF_INET, ipOnLine.c_str(), &(sa.sin_addr))) {
			cout << ipOnLine << endl;
		} else if (gethostbyname(ipOnLine.c_str()) != NULL) {
			cout << ipOnLine << endl;
		}
	}
	ifs.close();
}
void ps_setup::generatePorts(char* optarg) {
	char * pch;
	printf("Splitting string \"%s\" into tokens:\n", optarg);
	pch = strtok(optarg, ",");

	while (pch != NULL) {
		std::string str2(pch);
		if (str2.find("-") == -1) {
			printf("%s\n", pch);
		} else {
			string buffer = pch;
			int found = buffer.find("-");
			string temp = buffer.substr(0, found);
			int firstNo = stoi(temp);
			temp = buffer.substr(found + 1, buffer.length());
			int secondNo = stoi(temp);
			//cout<<firstNo<<endl;
			//cout<<secondNo<<endl;

			for (int i = firstNo; i <= secondNo; i++) {
				cout << i << " ";
			}
			cout << endl;

		}

		pch = strtok(NULL, ",");
	}

}
