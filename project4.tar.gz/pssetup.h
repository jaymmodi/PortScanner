/*
 * pssetup.h
 *
 *  Created on: Nov 2, 2014
 *      Author: vivek
 */

#ifndef PSSETUP_H_
#define PSSETUP_H_

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netdb.h>

using namespace std;

class ps_setup {
public:
	ps_setup();
	virtual ~ps_setup();
	void parseargs(int argc, char **argv);
	void printHelp();
	void generatePrefix(char* optarg);
	void openFile(char* optarg);
	void generatePorts(char* optarg);
};

#endif /* PSSETUP_H_ */
