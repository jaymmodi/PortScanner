//============================================================================
// Name        : PortScanner.cpp
// Author      :
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "pssetup.h"
using namespace std;

int main(int argc, char * argv[]) {
	ps_setup pssetup;
	pssetup.parseargs(argc,argv);
	return 0;
}
