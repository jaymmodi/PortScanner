/*
 * TCPUDPScan.cpp
 *
 *  Created on: Nov 15, 2014
 *      Author: jay
 */

#include "TCPUDPScan.h"

TCPUDPScan::TCPUDPScan() {
	// TODO Auto-generated constructor stub

}

TCPUDPScan::~TCPUDPScan() {
	// TODO Auto-generated destructor stub
}

void TCPUDPScan::generateChecksum(u_int16_t checksumValue, struct tcphdr*tcp,
		struct pseudo_tcpheader*psh) {
	//struct tcphdr tcpHeader;
	//struct pseudo_tcpheader * psh;
	//int sPort = 0;
	//int dPort = 0;
	int noOfwords = 0;
	int noOf16bitwords = 0;
	int noOfbytes = 0;
	u_int16_t word16bit = 0;
	u_int32_t sum = 0;
	char * ipFromList;
	//generateTCPHeader(&tcpHeader, sPort, dPort);
	cout << "Inside checksum" << endl;

	// to calculate number of bytes in TCP header.
	noOfwords = tcp->th_off;
	noOfbytes = noOfwords * 4;
	noOf16bitwords = noOfwords * 2; // number of 16 bit words is equal to number of 32 words * 2
//to convert TCP header to char * so that to get all bytes
	cout << "no of words" << noOfwords << endl;
	char * tcpHeaderToChar = (char *) tcp;

	// to form all 16 bit words from bytes
	for (int i = 0; i < noOfbytes; i = i + 2) {
		word16bit = (((unsigned int) tcpHeaderToChar[i] << 8) & 0xFF00)
				+ ((unsigned int) tcpHeaderToChar[i + 1] & 0xFF);
		sum = sum + (u_int32_t) word16bit;
	}
	// add pseudo tcp header in actual sum
	//generatePseudoTCPHeader(psh, dPort, ipFromList);
	char * pseudoHeaderToChar = (char *) psh;
	for (int i = 0; i < sizeof(struct pseudo_tcpheader); i = i + 2) {
		word16bit = (((unsigned int) pseudoHeaderToChar[i] << 8) & 0xFF00)
				+ ((unsigned int) pseudoHeaderToChar[i + 1] & 0xFF);
		sum = sum + (u_int32_t) word16bit;
	}

	// to add carry of 32 bit sum to itself.. as we need 1's complement of sum
	while (sum >> 16) {
		sum = (sum >> 16) + (sum & 0xFFFF);
	}
// again 1's complement.. this is checksum
	sum = ~sum;

	checksumValue = (u_int16_t) sum;

	tcp->check = htons(checksumValue);
	printf("%04X\n", checksumValue);
}

void TCPUDPScan::generateTCPHeader(struct tcphdr* tcp, int sPort, int dPort) {

	//TCP Header

	tcp->th_sport = htons(sPort);
	tcp->th_dport = htons(dPort);
	tcp->th_seq = 0;
	tcp->ack_seq = 0;
	tcp->th_off = 5;  //offset = tcp header size without options 5x4=20bytes
	tcp->fin = 0;
	tcp->syn = 0;
	tcp->rst = 0;
	tcp->psh = 0;
	tcp->ack = 0;
	tcp->urg = 0;
	tcp->th_win = htons(5840); //Assume 32 Byte Window
	tcp->check = 0; //Zeroed out will be filled by checksum function
	tcp->urg_ptr = 0;

}

void TCPUDPScan::generatePseudoTCPHeader(struct pseudo_tcpheader* psh,
		int dPort, char* ipFromList) {

	//Now the TCP checksum
	char myIP[16];
	memset(&myIP, '\0', sizeof(myIP));
	whatsMyIP(myIP);
	psh->source_address = inet_addr(myIP);

	struct sockaddr_in destSockAddr;

	memset(&destSockAddr, '\0', sizeof(destSockAddr));

	destSockAddr.sin_family = AF_INET;
	destSockAddr.sin_port = dPort;
	destSockAddr.sin_addr.s_addr = inet_addr(ipFromList);
	psh->dest_address = destSockAddr.sin_addr.s_addr;
	psh->placeholder = 0;
	psh->protocol = IPPROTO_TCP;
	psh->tcp_length = htons(sizeof(struct tcphdr));
}

void TCPUDPScan::whatsMyIP(char* myIP) {
	const char* openDns = "208.67.222.222";
	int openDnsPort = 53;
	int sockfd;
	struct sockaddr_in openDnsSockStruct;
	memset(&openDnsSockStruct, 0, sizeof(openDnsSockStruct));

	if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		cout << "Socket Initialization Failed" << endl;
	}

	openDnsSockStruct.sin_family = AF_INET;
	openDnsSockStruct.sin_addr.s_addr = inet_addr(openDns);
	openDnsSockStruct.sin_port = htons(openDnsPort);

	int err = connect(sockfd, (const struct sockaddr*) &openDnsSockStruct,
			sizeof(openDnsSockStruct));

	struct sockaddr_in DnsSockName;
	socklen_t DnsSockNameLen = sizeof(DnsSockName);
	err = getsockname(sockfd, (struct sockaddr*) &DnsSockName, &DnsSockNameLen);

	inet_ntop(AF_INET, &DnsSockName.sin_addr, myIP, 16);
	close(sockfd);

}

void TCPUDPScan::scanTCPport(char* ipToScan, int portToScan,
		string scanMethod) {
	u_int16_t checksumValue = 0;
	int sPort = 8000;
	struct sockaddr packetFrom;
	char packet[1024];
	char DotAddr[15];
//	char packet[1024];
//		char DotAddr[100];
	string flagToSet = scanMethod;

	struct sockaddr_in sa;

	if (inet_pton(AF_INET, ipToScan, &(sa.sin_addr))) {
		//DotAddr = ipToScan;
		sprintf(DotAddr,"%s",ipToScan);
	} else if (gethostbyname(ipToScan) != NULL) {
		struct hostent * h_ent_file;
		h_ent_file = gethostbyname(ipToScan);
		struct in_addr**addr_list_file =
				(struct in_addr**) h_ent_file->h_addr_list;
		//DotAddr = inet_ntoa(*addr_list_file[0]);
		sprintf(DotAddr,"%s",inet_ntoa(*addr_list_file[0]));
	} else {
		cout << "Wrong ip address" << ipToScan << endl;
		return;  							//return or pthread exit not sure
	}
	//init dest sockaddr
	struct tcphdr tcp;
	memset(&tcp, 0, sizeof(tcphdr));
	struct pseudo_tcpheader psh;
	memset(&psh, 0, sizeof(pseudo_tcpheader));
	struct sockaddr_in destHost;
	destHost.sin_family = AF_INET;

	destHost.sin_port = htons(portToScan);

	inet_aton(DotAddr, &destHost.sin_addr);
	// to create tcp header with checksum value as 0
	generateTCPHeader(&tcp, sPort, portToScan);
	if (flagToSet.compare("SYN") == 0) {
		tcp.syn = 1;
	} else if (flagToSet.compare("FIN") == 0) {
		tcp.fin = 1;
	} else if (flagToSet.compare("XMAS") == 0) {
		tcp.psh = 1;
		tcp.urg = 1;
		tcp.fin = 1;
	} else if (flagToSet.compare("ACK") == 0) {
		tcp.ack = 1;
	}

	//to create pseudo tcp header for checksum
	generatePseudoTCPHeader(&psh, portToScan, DotAddr);
	generateChecksum(checksumValue, &tcp, &psh);
	cout << ntohs(destHost.sin_port) << endl;
	cout << inet_ntoa(destHost.sin_addr) << endl;
	//logic to send to port
	int sendSocket = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
	cout << "Socket " << "\t" << sendSocket << endl;

	/*if (sendto(sendSocket, &tcp, sizeof(struct tcphdr), 0,
	 (struct sockaddr *) &destHost, sizeof(destHost)) == -1) {
	 cout << "Problem in sending" << endl;
	 cout << "Error Value :" << errno << endl;
	 //exit(1);

	 }

	 */
	sendTCPPacket(sendSocket, &tcp, &destHost);
	socklen_t len = sizeof(destHost);
	struct pollfd fds[2];
	int recvTCPSocket = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
	int recvICMPSocket = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
	fcntl(recvTCPSocket, F_SETFL, O_NONBLOCK);
	fcntl(recvICMPSocket, F_SETFL, O_NONBLOCK);
	int timeOut = 7000;
	int countForTimeOut = 3;
	bool tcpPacket = false;
	bool icmpPacket = false;

	fds[0].fd = recvTCPSocket;
	fds[0].events = 0;
	fds[0].events |= POLLIN;

	fds[1].fd = recvICMPSocket;
	fds[1].events = 0;
	fds[1].events |= POLLIN;

	char IP[15];

	int check;
	char abbc[15];
	do {
		int pollCheck = poll(fds, 2, timeOut);
		countForTimeOut--;
		memset(IP, '\0', 15);
		if (pollCheck < 0) {
			cout << "Error in Polling" << endl;
			cout << "Error No :" << "\t" << errno << endl;
		} else if (pollCheck == 0) {
			cout << "Timeout. No response" << endl;
			sendTCPPacket(sendSocket, &tcp, &destHost);

		} else {
			if (fds[0].revents & POLLIN) {
				pthread_mutex_lock(&recvMutex);
				tcpPacket = true;
				int bytesRecvdTCP = recvfrom(recvTCPSocket, packet,
						sizeof(destHost), 0, (struct sockaddr*) &destHost,
						&len);
				if (bytesRecvdTCP < 0) {

					cout << "Receive Error In TCP" << endl;
					cout << errno << endl;
					//exit(1);
				}
				pthread_mutex_unlock(&recvMutex);

			}
			if (fds[1].revents & POLLIN) {
				pthread_mutex_lock(&recvMutex);
				icmpPacket = true;
				int bytesRecvdICMP = recvfrom(recvICMPSocket, packet,
						sizeof(destHost), 0, (struct sockaddr*) &destHost,
						&len);
				if (bytesRecvdICMP < 0) {

					cout << "Receive Error In ICMP" << endl;
					//exit(1);
				}
				pthread_mutex_unlock(&recvMutex);
				break;
			}

		}
		memset(abbc,'\0',sizeof(abbc));
		strcpy(abbc,DotAddr);
		if (packet != NULL) {
			getIPfromPacket(packet, IP);
			cout << "IP FROM PACKET " << IP << endl;
		}

	} while (strcmp(IP, abbc) != 0 && countForTimeOut > 0);

	if (icmpPacket) {
		synAnalysis(packet, DotAddr, 1); // 0 - filtered port    1- do more analysis
	} else if (tcpPacket && countForTimeOut > 0) {
		synAnalysis(packet, DotAddr, 1);
	} else {
		synAnalysis(packet, DotAddr, 0);
	}

	close(sendSocket);
	close(recvICMPSocket);
	close(recvTCPSocket);
//delete[] packet;
//delete[] DotAddr;

}

void TCPUDPScan::generateChecksumUDP(u_int16_t checksumValue,
		struct udphdr* udp, struct pseudo_udpheader* psh) {
//struct tcphdr tcpHeader;
//struct pseudo_tcpheader * psh;
//int sPort = 0;
//int dPort = 0;
	int noOfbytes = 0;
	u_int16_t word16bit = 0;
	u_int32_t sum = 0;
	char * ipFromList;
//generateTCPHeader(&tcpHeader, sPort, dPort);
	cout << "Inside checksum UDP" << endl;

// to calculate number of bytes in TCP header.
	noOfbytes = sizeof(struct udphdr);
//to convert TCP header to char * so that to get all bytes
	char * tcpHeaderToChar = (char *) udp;

// to form all 16 bit words from bytes
	for (int i = 0; i < noOfbytes; i = i + 2) {
		word16bit = (((unsigned int) tcpHeaderToChar[i] << 8) & 0xFF00)
				+ ((unsigned int) tcpHeaderToChar[i + 1] & 0xFF);
		sum = sum + (u_int32_t) word16bit;
	}
// add pseudo tcp header in actual sum
//generatePseudoTCPHeader(psh, dPort, ipFromList);
	char * pseudoHeaderToChar = (char *) psh;
	for (int i = 0; i < sizeof(struct pseudo_udpheader); i = i + 2) {
		word16bit = (((unsigned int) pseudoHeaderToChar[i] << 8) & 0xFF00)
				+ ((unsigned int) pseudoHeaderToChar[i + 1] & 0xFF);
		sum = sum + (u_int32_t) word16bit;
	}

// to add carry of 32 bit sum to itself.. as we need 1's complement of sum
	while (sum >> 16) {
		sum = (sum >> 16) + (sum & 0xFFFF);
	}
// again 1's complement.. this is checksum
	sum = ~sum;

	checksumValue = (u_int16_t) sum;

	udp->check = htons(checksumValue);
	printf("%04X\n", checksumValue);
}

void TCPUDPScan::generateUDPHeader(struct udphdr* udph, int sPort, int dPort) {
	udph->source = htons(sPort);
	udph->dest = htons(dPort);
	udph->len = htons(sizeof(struct udphdr));
	udph->check = 0; 				//filled pseudo header

}

void TCPUDPScan::generatePseudoUDPHeader(struct pseudo_udpheader* psh,
		int dPort, char* ipFromList) {
//Now the UDP checksum
	char myIP[16];
	memset(&myIP, '\0', sizeof(myIP));
	whatsMyIP(myIP);
	psh->source_address = inet_addr(myIP);

	struct sockaddr_in destSockAddr;

	memset(&destSockAddr, '\0', sizeof(destSockAddr));

	destSockAddr.sin_family = AF_INET;
	destSockAddr.sin_port = dPort;
	destSockAddr.sin_addr.s_addr = inet_addr(ipFromList);
	psh->dest_address = destSockAddr.sin_addr.s_addr;
	psh->placeholder = 0;
	psh->protocol = IPPROTO_UDP;
	psh->udp_length = htons(sizeof(struct udphdr));
}
string TCPUDPScan::checkServices(char* ipToScan, int portToScan) {
	struct sockaddr_in checkServ;
	memset(&checkServ, '\0', sizeof(checkServ));
	checkServ.sin_family = AF_INET;
	checkServ.sin_port = htons(portToScan);
	checkServ.sin_addr.s_addr = inet_addr(ipToScan);

	int sockFD = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (sockFD < 0) {
		cout << "SocketFD initialization for Services Failed" << endl;
	}
	if (connect(sockFD, (struct sockaddr *) &checkServ, sizeof(checkServ))
			< 0) {
		return "UnKown Service";
	}
	switch (portToScan) {
	case 80: {
		char getRequest[50] = "GET / HTTP/1.1\r\n";
		send(sockFD, getRequest, strlen(getRequest), 0);
		char getResponse[1024]; //Took a random guess googles header 758 char long
		if (recv(sockFD, getResponse, 1024, 0) > 0) {
			string recvdResponse(getResponse);
			if ((recvdResponse.find("HTTP/1.1") == string::npos)
					|| (recvdResponse.find("HTTP/1.0") == string::npos)) {
				return "HTTP No Response To GET";
			} else {
				if (recvdResponse.find("HTTP/1.1") != string::npos) {
					return "HTTP 1.1";
				} else {
					return "HTTP 1.0";
				}
			}

		}
		break;
	}
	case 22: {
		char sshRequest[7] = "";
		send(sockFD, sshRequest, strlen(sshRequest), 0);
		char sshResponse[1024]; //Took a random guess googles header 758 char long
		int countBytes = recv(sockFD, sshResponse, 1024, 0);
		if (countBytes > 0) {
			string recvdResponse(sshResponse);
			return recvdResponse;
		}
		break;
	}
	case 24:
	case 25:
	case 587: {
		char smtpRequest[15] = "EHLO \r\n";
		send(sockFD, smtpRequest, strlen(smtpRequest), 0);
		char smtpResponse[200]; //Took a random guess smtp googles header 758 char long
		if (recv(sockFD, smtpResponse, 200, 0) > 0) {
			string recvdResponse(smtpResponse);
			if (recvdResponse.find("250") != string::npos) {
				return "ESMTP";
			} else {
				return "SMTP";
			}
		}
		break;
	}
	case 43: {
		std::string::size_type found;
		char whoisRequest[50] = "www.soic.indiana.edu\r\n";
		send(sockFD, whoisRequest, strlen(whoisRequest), 0);
		char whoisResponse[1024]; //Took a random guess smtp googles header 758 char long
		if (recv(sockFD, whoisResponse, 1024, 0) > 0) {
			char buffer[5];
			string recvdResponse(whoisResponse);
			if ((found = recvdResponse.find("Version")) != string::npos) {
				recvdResponse.copy(buffer, 4, found + strlen("Version") + 1);
				char reutrnversn[50];
				sprintf(reutrnversn, "WHOIS Version: %s", buffer);
				return reutrnversn;
			} else {
				return "Unknown WHOIS Version";
			}
		}
		break;
	}
	case 110: {
		std::string::size_type found;
		int countBytes = 0;
		char popRequest[20] = "\r\n";
		send(sockFD, popRequest, strlen(popRequest), 0);
		char popResponse[200]; //Took a random guess smtp googles header 758 char long
		if (recv(sockFD, popResponse, 200, 0) > 0) {
			char buffer[5];
			string recvdResponse(popResponse);
			if ((found = recvdResponse.find("+OK")) != string::npos) {
				return "POP Active";
			}
		}
		break;
	}
	case 143: {
		std::string::size_type found;
		int countBytes = 0;
		char imapRequest[20] = "\r\n";
		send(sockFD, imapRequest, strlen(imapRequest), 0);
		char imapResponse[1024]; //Took a random guess smtp googles header 758 char long
		if (recv(sockFD, imapResponse, 1024, 0) > 0) {
			char buffer[5];
			string recvdResponse(imapResponse);
			if ((found = recvdResponse.find("IMAP")) != string::npos) {
				recvdResponse.copy(buffer, 10, found);
				char reutrnversn[50];
				sprintf(reutrnversn, "IMAP Version: %s", buffer);
				return reutrnversn;
			}
		}
		break;
	}
	default:
		return "UnKown Service";
	}
}
void TCPUDPScan::scanUDPport(char* ipToScan, int portToScan) {
	u_int16_t checksumValue = 0;
	int sPort = 8000;
	struct sockaddr packetFrom;
	char packet[1024];
	char DotAddr[100];
	int sendSocketUDP = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);

	struct sockaddr_in sa;
//IP entered by user check
	if (inet_pton(AF_INET, ipToScan, &(sa.sin_addr))) {
		strcpy(DotAddr, ipToScan);
		//DotAddr = ipToScan;
	} else if (gethostbyname(ipToScan) != NULL) {
		struct hostent * h_ent_file;
		h_ent_file = gethostbyname(ipToScan);
		struct in_addr**addr_list_file =
				(struct in_addr**) h_ent_file->h_addr_list;
		strcpy(DotAddr, inet_ntoa(*addr_list_file[0]));
		//DotAddr = inet_ntoa(*addr_list_file[0]);
	} else {
		cout << "Wrong ip address" << ipToScan << endl;
		return;  							//return or pthread exit not sure
	}
//init dest soctcpkaddr
	struct udphdr udp;
	memset(&udp, 0, sizeof(udphdr));
	struct pseudo_udpheader psh;
	memset(&psh, 0, sizeof(pseudo_udpheader));
	struct sockaddr_in destHost;
	destHost.sin_family = AF_INET;

	destHost.sin_port = htons(portToScan);

	inet_aton(DotAddr, &destHost.sin_addr);
	if (portToScan == 53) {
		unsigned char buf[65536];
		struct udphdr *udp = (struct udphdr *) buf;
		// to create tcp header with checksum value as 0
		generateUDPHeader(udp, sPort, portToScan);

		//to create pseudo tcp header for checksum
		generatePseudoUDPHeader(&psh, portToScan, DotAddr);

		struct DNShdr *dns = (struct DNShdr *) (buf + sizeof(struct udphdr));
		dns->id = (unsigned short) htons(getpid());
		dns->qr = 0; //This is a query
		dns->opcode = 0; //This is a standard query
		dns->aa = 0; //Not Authoritative
		dns->tc = 0; //This message is not truncated
		dns->rd = 0; //Recursion Desired
		dns->ra = 0; //Recursion not available! hey we dont have it (lol)
		dns->z = 0;
		dns->ad = 0;
		dns->cd = 0;
		dns->rcode = 0;
		dns->q_count = htons(1); //we have only 1 question
		dns->ans_count = 0;
		dns->auth_count = 0;
		dns->add_count = 0;
		dns->qname = '\0';
		dns->qclass = htons(1);
		dns->qtype = htons(1);

		udp->len = htons(sizeof(struct udphdr) + sizeof(struct DNShdr));
		psh.udp_length = htons(sizeof(struct udphdr) + sizeof(struct DNShdr));
		generateChecksumUDP(checksumValue, (struct udphdr *) buf, &psh);
		udp->check = checksumValue;

		if (sendto(sendSocketUDP, buf,
				sizeof(struct udphdr) + sizeof(struct DNShdr), 0,
				(struct sockaddr *) &destHost, sizeof(destHost)) == -1) {
			cout << "Problem in sending" << endl;
			cout << "Error Value :" << errno << endl;
			exit(1);

		}
	} else {
		char buf[65536];
		char* data = buf + sizeof(struct udphdr);
		strcpy(data, "RandomJunkPayload");
		// to create tcp header with checksum value as 0
		struct udphdr *udp = (struct udphdr *) buf;
		generateUDPHeader(udp, sPort, portToScan);

		//to create pseudo tcp header for checksum
		generatePseudoUDPHeader(&psh, portToScan, DotAddr);
		udp->len = htons(sizeof(struct udphdr) + strlen(data));
		psh.udp_length = htons(sizeof(struct udphdr) + strlen(data));
		generateChecksumUDP(checksumValue, udp, &psh);
		udp->check = checksumValue;
		cout << ntohs(destHost.sin_port) << endl;
		cout << inet_ntoa(destHost.sin_addr) << endl;
		//logic to send to port

		cout << "hellooooos" << endl;
		if (sendto(sendSocketUDP, buf, sizeof(struct udphdr) + strlen(data), 0,
				(struct sockaddr *) &destHost, sizeof(destHost)) == -1) {
			cout << "Problem in sending" << endl;
			cout << "Error Value :" << errno << endl;
			//exit(1);

		}
	}
	socklen_t len = sizeof(destHost);
	struct pollfd fds[2];
	int recvUDPSocket = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
	int recvUDPICMPSocket = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
	int timeOut = 4000;
	fds[0].fd = recvUDPSocket;
	fds[0].events = 0;
	fds[0].events |= POLLIN;

	fds[1].fd = recvUDPICMPSocket;
	fds[1].events = 0;
	fds[1].events |= POLLIN;

	int pollCheck = poll(fds, 2, timeOut);
	if (pollCheck < 0) {
		cout << "Error in Polling" << endl;
		cout << "Error No :" << "\t" << errno << endl;
	} else if (pollCheck == 0) {

		cout << "Timeout. No response" << endl;
	} else {
		if (fds[0].revents & POLLIN) {
			pthread_mutex_lock(&recvMutex);
			int bytesRecvdTCP = recvfrom(recvUDPSocket, packet,
					sizeof(destHost), 0, (struct sockaddr*) &destHost, &len);
			if (bytesRecvdTCP == -1) {

				cout << "Receive Error In TCP" << endl;
				cout << errno << endl;
				//exit(1);
			}
			pthread_mutex_unlock(&recvMutex);
		}
		if (fds[1].revents & POLLIN) {
			pthread_mutex_lock(&recvMutex);
			int bytesRecvdICMP = recvfrom(recvUDPICMPSocket, packet,
					sizeof(destHost), 0, (struct sockaddr*) &destHost, &len);
			if (bytesRecvdICMP == -1) {

				cout << "Receive Error In ICMP" << endl;
				//exit(1);
			}
			pthread_mutex_unlock(&recvMutex);
		}

	}
	/*for (int i = 0; i < 100; i++) {
	 printf("%02X \t", packet[i]);
	 }
	 cout << "\n" << endl;*/

	close(recvUDPICMPSocket);
	close(recvUDPSocket);
	close(sendSocketUDP);
//delete[] packet;
//delete[] DotAddr;
}

void TCPUDPScan::sendTCPPacket(int sendSocket, struct tcphdr *tcp,
		struct sockaddr_in *destHost) {

	if (sendto(sendSocket, tcp, sizeof(struct tcphdr), 0,
			(struct sockaddr *) destHost, sizeof(struct sockaddr_in)) == -1) {
		cout << "Problem in sending" << endl;
		cout << "Error Value :" << errno << endl;
		//exit(1);

	}

}

void TCPUDPScan::synAnalysis(char* packet, char* DotAddr, int check) {
	struct iphdr* ip_header = (struct iphdr*) (packet);

	if (check == 1) {
		struct tcphdr * tcpheader = (struct tcphdr*) (packet
				+ ip_header->ihl * 4 + sizeof(struct icmphdr));
		cout << "DO MORE ANALYSIS" << ntohs(tcpheader->dest) << endl;

	} else {
		cout << "PORT FILTERED" << endl;
	}

}

void TCPUDPScan::getIPfromPacket(char* packet, char*IP) {

	struct iphdr* ip_header = (struct iphdr*) (packet);
	struct sockaddr_in ipSource;
	memset(&ipSource, 0, sizeof(ipSource));
	ipSource.sin_addr.s_addr = ip_header->saddr;
	sprintf(IP, "%s", inet_ntoa(ipSource.sin_addr));
	cout << "INSIDE METHOD" << IP << endl;
}
