/*
 * TCPUDPScan.h
 *
 *  Created on: Nov 15, 2014
 *      Author: jay
 */

#ifndef TCPUDPSCAN_H_
#define TCPUDPSCAN_H_
#include "pssetup.h"


class TCPUDPScan {
public:
	TCPUDPScan();
	virtual ~TCPUDPScan();
	pthread_mutex_t recvMutex = PTHREAD_MUTEX_INITIALIZER;
	void generateChecksum(u_int16_t checksumValue, struct tcphdr*tcp,struct pseudo_tcpheader*psh);
	void generateChecksumUDP(u_int16_t checksumValue, struct udphdr*tcp,struct pseudo_udpheader*psh);
	void generateTCPHeader(struct tcphdr* tcph, int sPort, int dPort);
	void generateUDPHeader(struct udphdr* udph, int sPort, int dPort);
	void generatePseudoTCPHeader(struct pseudo_tcpheader* psh, int dPort,
			char* ipFromList);
	void generatePseudoUDPHeader(struct pseudo_udpheader* psh, int dPort,
			char* ipFromList);
	void whatsMyIP(char* myIP);
	void scanTCPport(struct parseV * parseValues,string flagToSet);
	void createTCPheaderWithCorrectChecksum(struct tcphdr * tcp);
	void createIPheader(struct iphdr* ipheader,struct parseV);
	void scanTCPport(char* ipToScan,int portToScan,string scanMethod);
    void scanUDPport(char* ipToScan,int portToScan);
    string checkServices(char* ipToScan, int portToScan);
    void sendTCPPacket(int sendSocket,struct tcphdr *tcp,struct sockaddr_in *destHost);
    void synAnalysis(char* packet,char* DotAddr,int check);
    void getIPfromPacket(char*packet,char*IP);


};

#endif /* TCPUDPSCAN_H_ */
