//============================================================================
// Name        : PortScanner.cpp
// Author      :
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "pssetup.h"
#include <string.h>
#include <list>
#include <pthread.h>
#include "TCPUDPScan.h"
struct parseV parseValues;
list<struct differentJobs*> jobList; // common job list                     // TODO: DO NOT FORGET TO DELETE VECTOR AT THE END. CHECK MEMORY LEAK.
list<struct activeJobs*> activeJobsList;    // list for active jobs
list<struct differentJobs*>::iterator it;   // iterator for job list
list<struct activeJobs*>::iterator it_activeJobs; // iterator for active jobs
pthread_mutex_t distinctJobMutex = PTHREAD_MUTEX_INITIALIZER; // mutex for common job list
pthread_mutex_t activeJobMutex = PTHREAD_MUTEX_INITIALIZER; // mutex for common job list

struct activeJobs * activeJob = new struct activeJobs;
using namespace std;

void* startScan(void * ptr) {
	TCPUDPScan tcpUdpScan;
	char *ip;
	int port;
	string scanType;
	struct differentJobs *jobs;
	while (true) {
		pthread_mutex_lock(&distinctJobMutex);
		if (jobList.size() > 0) {
			// lock...take job.. remove job..unlock Mutex
			jobs = jobList.front();
			ip = jobs->ip;
			port = jobs->port;
			scanType = jobs->scanMethod;
			//delete jobList.front();
			//delete jobs;
			jobList.remove(jobs);
			pthread_mutex_unlock(&distinctJobMutex);
		} else {
			pthread_mutex_unlock(&distinctJobMutex);
			break;
		}
		/*if (parseValues.ipAddressList.size() == 1) {
			if (scanType.compare("UDP") == 0) {
				tcpUdpScan.scanUDPport(ip, port); // scan udp port
			} else {
				cout << ip << "\t" << scanType << "\t" << port;
				count++;
				tcpUdpScan.scanTCPport(ip, port, scanType);
			}*/
	//	} else {
			pthread_mutex_lock(&activeJobMutex);
			bool isSameIpAndPortJob = true;
			if (!(activeJobsList.empty())) {
				// will go inside only if active job list is not empty
				for (it_activeJobs = activeJobsList.begin();
						it_activeJobs != activeJobsList.end();
						it_activeJobs++) {
					//bool isSameIpAndPortJob = true;
					struct activeJobs * localAJStruct = *it_activeJobs;
					int check = memcmp(jobs->ip, localAJStruct->ip, 50); // to check whether a new job is present in active jobs list or not
					bool checkIp = false; // to check for IP in both active job list and different job list
					if (check == 0) {
						checkIp = true;
					}
					if (!(checkIp && (localAJStruct->port == jobs->port))) { // go inside if its a new job with different ip and different port
						cout << "new distinct job " << endl;
						//call tcp or udp method with localDJStruct
						isSameIpAndPortJob = false;
						activeJob->ip = jobs->ip;
						activeJob->port = jobs->port;
						activeJobsList.push_back(activeJob); // if different job then add to active jobs list

						cout << jobs->ip << jobs->scanMethod << jobs->port
								<< endl;
						ip = jobs->ip;
						port = jobs->port;
						scanType = jobs->scanMethod;
						//delete jobList.front();
						//delete jobList.front();
						delete jobs;
						jobList.remove(jobs); // remove distinct from different jobs list after assigning it properly
						//delete jobs;
						pthread_mutex_unlock(&activeJobMutex);
						cout<< "thread no"<<pthread_self() <<endl;
						if (scanType.compare("UDP") == 0) {
							tcpUdpScan.scanUDPport(ip, port); // scan udp port
						} else {
							tcpUdpScan.scanTCPport(ip, port, scanType);
						}
						break;
					}
					/*if (isSameIpAndPortJob) {
					 pthread_mutex_lock(&distinctJobMutex);
					 jobList.push_back(jobs);
					 pthread_mutex_unlock(&distinctJobMutex);
					 }*/
					pthread_mutex_unlock(&activeJobMutex);
				}
				if (isSameIpAndPortJob) {
					pthread_mutex_lock(&distinctJobMutex);
					jobList.push_back(jobs);
					pthread_mutex_unlock(&distinctJobMutex);
				}
			} else {
				// put 1st job in active queue;
				cout << "1st job" << endl;
				activeJob->ip = jobs->ip;
				activeJob->port = jobs->port;
				activeJobsList.push_back(activeJob); // if different job then add to active jobs list
				ip = jobs->ip;
				port = jobs->port;
				scanType = jobs->scanMethod;
				//delete jobList.front();
				delete jobs;
				jobList.remove(jobs); // remove distinct from different jobs list after assigning it properly
				//pthread_mutex_unlock(&distinctJobMutex);
				pthread_mutex_unlock(&activeJobMutex);
				if (scanType.compare("UDP") == 0) {
					cout << "INSIDE UDP" << endl;
					tcpUdpScan.scanUDPport(ip, port); // scan udp port
				} else {
					cout << ip << "\t" << scanType << "\t" << port;
					tcpUdpScan.scanTCPport(ip, port, scanType);
				}
			}
			//pthread_mutex_unlock(&activeJobMutex);

	}
//	}

	//pthread_exit(NULL);

	return NULL;
}

int main(int argc, char * argv[]) {
	ps_setup pssetup;

	struct differentJobs jobs;
	TCPUDPScan tCPUDPScan;
	string flagToSet = "";
//list of jobs

//parse arguments
	pssetup.parseargs(argc, argv, &parseValues);

// to create number of jobs
	int noOfjobs = parseValues.ipAddressList.size()
			* parseValues.portsList.size() * parseValues.noOfmethodsToScan;
	it = jobList.begin();
	for (int i = 0; i < parseValues.ipAddressList.size(); i++) {
		for (int j = 0; j < parseValues.portsList.size(); j++) {

			if (parseValues.scanMethod[0] == 1) {
				jobList.push_back(new struct differentJobs);
				struct differentJobs* insideJobs = jobList.back();
				insideJobs->ip = parseValues.ipAddressList.at(i);
				insideJobs->port = parseValues.portsList.at(j);
				insideJobs->scanMethod = "SYN";

			}
			if (parseValues.scanMethod[1] == 1) {
				jobList.push_back(new struct differentJobs);
				struct differentJobs* insideJobs = jobList.back();
				insideJobs->ip = parseValues.ipAddressList.at(i);
				insideJobs->port = parseValues.portsList.at(j);
				insideJobs->scanMethod = "FIN";
			}
			if (parseValues.scanMethod[2] == 1) {
				jobList.push_back(new struct differentJobs);
				struct differentJobs* insideJobs = jobList.back();
				insideJobs->ip = parseValues.ipAddressList.at(i);
				insideJobs->port = parseValues.portsList.at(j);
				insideJobs->scanMethod = "XMAS";
			}
			if (parseValues.scanMethod[3] == 1) {
				jobList.push_back(new struct differentJobs);
				struct differentJobs* insideJobs = jobList.back();
				insideJobs->ip = parseValues.ipAddressList.at(i);
				insideJobs->port = parseValues.portsList.at(j);
				insideJobs->scanMethod = "NULL";
			}
			if (parseValues.scanMethod[4] == 1) {
				cout << "UDP" << endl;
				jobList.push_back(new struct differentJobs);
				struct differentJobs* insideJobs = jobList.back();
				insideJobs->ip = parseValues.ipAddressList.at(i);
				insideJobs->port = parseValues.portsList.at(j);
				insideJobs->scanMethod = "UDP";
			}
			if (parseValues.scanMethod[5] == 1) {
				jobList.push_back(new struct differentJobs);
				struct differentJobs* insideJobs = jobList.back();
				insideJobs->ip = parseValues.ipAddressList.at(i);
				insideJobs->port = parseValues.portsList.at(j);
				insideJobs->scanMethod = "ACK";
			}

		}

	}

	/*for (list<struct differentJobs*>::iterator it = jobList.begin();
	 it != jobList.end(); it++) {
	 struct differentJobs * tp = *it;
	 cout << tp->ip << "\t" << tp->port << "\t" << tp->scanMethod << endl;
	 }*/

	/*if (jobs.scanMethod == "UDP") {
	 tCPUDPScan.scanUDPport(&jobs);
	 } else {
	 tCPUDPScan.scanTCPport1(&jobs);
	 }
	 */
// 0 - syn   1 - fin    2 -xmas    3 - null   4 -udp  5- ack
	pthread_t th[parseValues.noOfThreads];
	int threadReturn = 0;
	for (int i = 0; i < parseValues.noOfThreads; i++) {
		threadReturn = pthread_create(&th[i], NULL, startScan, (void*) NULL);

		if (threadReturn) {
			cout << "Error Creating in thread" << endl;
			exit(1);
		}
		pthread_join(th[i], NULL);

	}

	/*for (int i = 0; i < parseValues.ipAddressList.size(); i++) {
	 delete[] &parseValues.ipAddressList.at(i);
	 }

	 for (int i = 0; i < parseValues.portsList.size(); i++) {
	 delete[] &parseValues.portsList.at(i);
	 }
	 for(int i =0;i<jobList.size();i++)
	 {
	 delete[] jobList.front();
	 jobList.pop_front();
	 }
	 */
	cout << "End main" << endl;

	return 0;
}
